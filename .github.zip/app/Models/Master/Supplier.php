<?php

namespace App\Models\Master;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Supplier extends Model
{
    use HasFactory;

    // Define fillable attributes
 protected $fillable = [
        'company_id',
        'unique_no',
        'name',
        'company_name',
        'owner_name',
        'owner_mobile_no',
        'owner_cnic_no',
        'next_to_kin',
        'next_to_kin_mobile_no',
        'owner_bank_detail',
        'company_bank_detail',
        'prefix',
        'email',
        'phone',
        'address',
        'ntn',
        'stn',
        'attachment',
        'status'
    ];

    // Define the relationship with Company (assuming the 'Company' model exists)
    public function company()
    {
        return $this->belongsTo(Company::class); // Adjust the model name if needed
    }
}