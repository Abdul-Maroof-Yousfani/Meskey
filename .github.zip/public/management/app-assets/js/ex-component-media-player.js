$(document).ready(function () {
  // video player  define
  var v_player = new Plyr(".video-player");
  // audio player define
  var a_player = new Plyr(".audio-player");
});
