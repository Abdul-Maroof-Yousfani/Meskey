<?php

return [
    'ffmpeg' => [
        'binaries' => 'C:/ffmpeg/bin/ffmpeg.exe',
        'threads' => 12,
    ],
    'ffprob' => [
        'binaries' => 'C:/ffmpeg/bin/ffprobe.exe',
    ],
];
