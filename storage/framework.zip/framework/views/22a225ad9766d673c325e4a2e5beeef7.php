<form action="<?php echo e(route('raw-data.store')); ?>" method="POST" id="ajaxSubmit" autocomplete="off">
    <?php echo csrf_field(); ?>
    <input type="hidden" id="listRefresh" value="<?php echo e(route('get.raw-data')); ?>" />

    <div class="row form-mar">
<?php echo e(csrf_token()); ?>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <fieldset class="form-group">
                <label for="inputGroupFile01">Upload File</label>
                <div class="custom-file">
                    <input type="file" name="file" class="custom-file-input" id="inputGroupFile01">
                    <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                </div>
            </fieldset>
        </div>
    </div>
    <div class="row bottom-button-bar">
        <div class="col-12">
            <a type="button" class="btn btn-danger modal-sidebar-close position-relative top-1 closebutton">Close</a>
            <button type="submit" class="btn btn-primary submitbutton">Save</button>
        </div>
    </div>
</form><?php /**PATH C:\xampp82\htdocs\jazacrm\resources\views/management/master/rawData/create.blade.php ENDPATH**/ ?>