<?php echo $__env->make('management/layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-panel">
    <div class="wrapper">
        <?php if(getCurrentCompany()): ?>
            <?php echo $__env->make('management/layouts/navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <!-- BEGIN : Main Content-->
        <div class="main-content py-4">
            <div class="content-overlay"></div>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</div>
<?php echo $__env->make('management/layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('scripts'); ?>
<?php echo $__env->make('management/layouts/modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp82\htdocs\jazacrm\resources\views/management/layouts/master.blade.php ENDPATH**/ ?>