<?php echo Form::model($user, ['method' => 'PATCH', 'route' => ['users.update', $user->id], 'id' => 'ajaxSubmit']); ?>

<input type="hidden" id="url" value="<?php echo e(route('users.index')); ?>" />

<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <label>Name:</label>
            <?php echo Form::text('name', null, ['placeholder' => 'Name', 'class' => 'form-control']); ?>

        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <label>Email:</label>
            <?php echo Form::text('email', null, ['placeholder' => 'Email', 'class' => 'form-control']); ?>

        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <label>Password:</label>
            <?php echo Form::password('password', ['placeholder' => 'Password', 'class' => 'form-control']); ?>

        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <label>Confirm Password:</label>
            <?php echo Form::password('confirm-password', ['placeholder' => 'Confirm Password', 'class' => 'form-control']); ?>

        </div>
    </div>
    
    
    
    
    
    

</div>

<div id="card-container" class="mb-4">
    <?php $__currentLoopData = getUserAllCompanies($user->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignedCompany): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="clonecard border-1">
            <hr>
            <div class="row justify-content-center">
                <div class="col-xs-5 col-sm-5 col-md-5">
                    <div class="form-group m-0">
                        <label>Company:</label>
                        <select name="company[]" class="form-control">
                            <?php $__currentLoopData = getAllCompanies(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e($company->id == $assignedCompany->id ? 'selected' : ''); ?>

                                    value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-xs-5 col-sm-5 col-md-5">
                    <div class="form-group m-0">
                        <label>Role:</label>
                        <select name="role[]" class="form-control">
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e($assignedCompany->pivot->role_id == $role->id ? 'selected' : ''); ?>

                                    value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-xs-2 col-sm-2 col-md-2 d-flex align-items-end">
                    <div>
                        <button type="button" class="btn btn-warning btn-icon add-more   mr-1 "><i
                                class="fa fa-plus"></i></button>
                        <button type="button" class="btn btn-danger btn-icon remove-card  mr-1 "><i
                                class="fa fa-trash"></i></button>

                    </div>
                    
                </div>
            </div>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="row bottom-button-bar">
    <div class="col-12">
        <a type="button" class="btn btn-danger modal-sidebar-close position-relative top-1 closebutton">Close</a>
        <button type="submit" class="btn btn-primary submitbutton">Save</button>
    </div>
</div>
<?php echo Form::close(); ?>

<script>
    // Function to add more cards
    // Function to toggle visibility of the Remove button
    function toggleRemoveButton() {
        if ($('#card-container .clonecard').length === 1) {
            $('#card-container .clonecard .remove-card').hide(); // Hide Remove button
        } else {
            $('#card-container .clonecard .remove-card').show(); // Show Remove button
        }
    }

    // Initialize Remove button visibility
    toggleRemoveButton();

    // Add More button click event
    $('body').on('click', '.add-more', function() {
        var newCard = $('#card-container .clonecard:first').clone(); // Clone the first card
        newCard.find('select').val(''); // Clear select values
        $('#card-container').append(newCard); // Append the new card
        toggleRemoveButton(); // Toggle Remove button visibility
    });

    // Remove button click event
    $(document).on('click', '.remove-card', function() {
        if ($('#card-container .clonecard').length > 1) {
            $(this).closest('.clonecard').remove(); // Remove the specific card
            toggleRemoveButton(); // Toggle Remove button visibility
        }
    });
</script>
<?php /**PATH C:\xampp82\htdocs\jazacrm\resources\views/management/acl/users/edit.blade.php ENDPATH**/ ?>