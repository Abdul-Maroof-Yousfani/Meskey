<!DOCTYPE html>
<html class="loading" lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="description"
        content="Apex admin is super flexible, powerful, clean &amp; modern responsive bootstrap 4 admin template with unlimited possibilities.">
    <meta name="keywords"
        content="admin template, Apex admin template, dashboard template, flat admin template, responsive admin template, web app">
    <meta name="author" content="PIXINVENT">
    <title>Login - <?php echo e(config('app.name')); ?></title>
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('management')); ?>/app-assets/img/ico/favicon.ico">
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('management')); ?>/app-assets/img/ico/favicon-32.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <link
        href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,700,900%7CMontserrat:300,400,500,600,700,800,900"
        rel="stylesheet">

    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('management/app-assets/fonts/font-awesome/css/font-awesome.min.css')); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('management/app-assets/css/bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('management/app-assets/css/bootstrap-extended.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('management/app-assets/css/components.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('management/app-assets/css/pages/authentication.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('management/app-assets/css/themes/layout-dark.css')); ?>">


</head>

<body class="horizontal-layout horizontal-menu horizontal-menu-padding 1-column auth-page navbar-sticky blank-page <?php echo e(Cookie::get('layout') === 'dark' ? 'layout-dark' : ''); ?>"
    data-open="hover" data-menu="horizontal-menu" data-col="1-column">
    <div class="wrapper">
        <div class="main-panel">
            <!-- BEGIN : Main Content-->
            <div class="main-content">
                <div class="content-overlay"></div>
                <div class="content-wrapper">
                    <!--Login Page Starts-->
                    <section id="login" class="auth-height">
                        <div class="row full-height-vh m-0">
                            <div class="col-12 d-flex align-items-center justify-content-center">
                                <div class="card overflow-hidden">
                                    <div class="card-content">
                                        <div class="card-body auth-img">
                                            <div class="row m-0">
                                                <div
                                                    class="col-lg-6 d-none d-lg-flex justify-content-center align-items-center auth-img-bg p-3">
                                                    <img src="<?php echo e(image_path('management/app-assets/img/jazaa-logo.png')); ?>"
                                                        alt="" class="img-fluid" width="300" height="230">
                                                </div>
                                                <div class="col-lg-6 col-12 px-4 py-4">
                                                    <form method="POST" class="needs-validation mb-6" novalidate
                                                        action="<?php echo e(route('login')); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <h4 class="mb-2 card-title">Login</h4>
                                                        <p>Welcome back, please login to your account.</p>
                                                        <?php if(session('message')): ?>
                                                            <div class="alert alert-warning alert-dismissible fade show"
                                                                role="alert">
                                                                <?php echo e(session('message')); ?>

                                                                <button type="button" class="btn-close"
                                                                    data-bs-dismiss="alert" aria-label="Close"></button>
                                                            </div>
                                                        <?php endif; ?>
                                                        <div class="my-2">
                                                            <input id="signinEmailInput" placeholder="Email Address"
                                                                type="email"
                                                                class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                name="email" value="<?php echo e(old('email')); ?>" required
                                                                autocomplete="email" autofocus>
                                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <?php echo e($message); ?>

                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                        <div class="my-2">
                                                            <input id="formSignUpPassword" type="password"
                                                                placeholder="Password"
                                                                class="form-control fakePassword <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                name="password" required
                                                                autocomplete="current-password">



                                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <?php echo e($message); ?>

                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                        <div
                                                            class="d-sm-flex justify-content-between mb-3 font-small-2">
                                                            <div class="remember-me mb-2 mb-sm-0">
                                                                <div class="checkbox auth-checkbox">
                                                                    <input class="form-check-input" name="remember"
                                                                        id="rememberMeCheckbox"
                                                                        <?php echo e(old('remember') ? 'checked' : ''); ?>

                                                                        type="checkbox" />

                                                                    <label for="rememberMeCheckbox"><span>Remember
                                                                            Me</span></label>
                                                                </div>
                                                            </div>


                                                            <?php if(Route::has('password.request')): ?>
                                                                <a class="text-primary"
                                                                    href="<?php echo e(route('password.request')); ?>">
                                                                    <?php echo e(__('Forgot Password?')); ?>

                                                                </a>
                                                            <?php endif; ?>

                                                        </div>
                                                        <div
                                                            class="d-flex justify-content-end flex-sm-row flex-column">
                                                            
                                                            <button type="submit"
                                                                class="btn btn-primary">Login</button>
                                                        </div>


                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <!--Login Page Ends-->
                </div>
            </div>
            <!-- END : End Main Content-->
        </div>
    </div>

</body>
<script src="<?php echo e(asset('frontend/assets/js/vendors/password.js')); ?>"></script>

</html>
<?php /**PATH C:\xampp82\htdocs\jazaafoods\resources\views/auth/login.blade.php ENDPATH**/ ?>