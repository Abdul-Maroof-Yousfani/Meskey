
<form method="POST" action="<?php echo e(route('company.update', $raw_data->id)); ?>" id="ajaxSubmit" enctype="multipart/form-data"> 
<?php echo method_field('PUT'); ?>
    <input type="hidden" id="listRefresh" value="<?php echo e(route('get.regions')); ?>" />

    <div class="row form-mar">
       
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group ">
                <label>Country:</label>
                <input type="text" name="name" value="<?php echo e($raw_data->country); ?>" placeholder="Name" class="form-control" autocomplete="off" />
            </div>
        </div>
        <div class="col-xs-6 col-sm-6 col-md-6">
            <div class="form-group ">
                <label>Exporter Name:</label>
                <input type="text" name="name" value="<?php echo e($raw_data->exporter_name); ?>" placeholder="Name" class="form-control" autocomplete="off" />
            </div>
        </div>
        <div class="col-xs-6 col-sm-6 col-md-6">
            <div class="form-group ">
                <label>Importer Name:</label>
                <input type="text" name="name" value="<?php echo e($raw_data->importers_name); ?>" placeholder="Name" class="form-control" autocomplete="off" />
            </div>
        </div>
        <div class="col-xs-6 col-sm-6 col-md-6">
            <div class="form-group ">
                <label>Item Description:</label>
                <input type="text" name="name" value="<?php echo e($raw_data->item_description); ?>" placeholder="Name" class="form-control" autocomplete="off" />
            </div>
        </div>
        <div class="col-xs-3 col-sm-3 col-md-3">
            <div class="form-group ">
                <label>Qty:</label>
                <input type="text" name="name" value="<?php echo e($raw_data->qty); ?>" placeholder="Name" class="form-control" autocomplete="off" />
            </div>
        </div>
        <div class="col-xs-3 col-sm-3 col-md-3">
            <div class="form-group ">
                <label>unit:</label>
                <input type="text" name="name" value="<?php echo e($raw_data->unit); ?>" placeholder="Name" class="form-control" autocomplete="off" />
            </div>
        </div>
        <div class="col-xs-3 col-sm-3 col-md-3">
            <div class="form-group ">
                <label>UPRC:</label>
                <input type="text" name="name" value="<?php echo e($raw_data->uprc); ?>" placeholder="Name" class="form-control" autocomplete="off" />
            </div>
        </div>
        <div class="col-xs-3 col-sm-3 col-md-3">
            <div class="form-group ">
                <label>Exp Val:</label>
                <input type="text" name="name" value="<?php echo e($raw_data->exp_val); ?>" placeholder="Name" class="form-control" autocomplete="off" />
            </div>
        </div>
        <div class="col-xs-3 col-sm-3 col-md-3">
            <div class="form-group ">
                <label>Unit Price FC:</label>
                <input type="text" name="name" value="<?php echo e($raw_data->unit_price_fc); ?>" placeholder="Unit Price FC" class="form-control" autocomplete="off" />
            </div>
        </div>
        <div class="col-xs-3 col-sm-3 col-md-3">
            <div class="form-group ">
                <label>Total Value FC:</label>
                <input type="text" name="name" value="<?php echo e($raw_data->total_value_fc); ?>" placeholder="Total Value FC" class="form-control" autocomplete="off" />
            </div>
        </div>
        <div class="col-xs-3 col-sm-3 col-md-3">
            <div class="form-group ">
                <label>SB No:</label>
                <input type="text" name="name" value="<?php echo e($raw_data->sb_no); ?>" placeholder="SB No" class="form-control" autocomplete="off" />
            </div>
        </div>
        <div class="col-xs-3 col-sm-3 col-md-3">
            <div class="form-group ">
                <label>HS Code:</label>
                <input type="text" name="name" value="<?php echo e($raw_data->hs_code); ?>" placeholder="HS Code" class="form-control" autocomplete="off" />
            </div>
        </div>
        <div class="col-xs-3 col-sm-3 col-md-3">
            <div class="form-group ">
                <label>Currency:</label>
                <input type="text" name="name" value="<?php echo e($raw_data->cur); ?>" placeholder="HS Code" class="form-control" autocomplete="off" />
            </div>
        </div>
        <div class="col-xs-3 col-sm-3 col-md-3">
            <div class="form-group ">
                <label>Cur Cod:</label>
                <input type="text" name="name" value="<?php echo e($raw_data->cur_cod); ?>" placeholder="HS Code" class="form-control" autocomplete="off" />
            </div>
        </div>
        <div class="col-xs-3 col-sm-3 col-md-3">
            <div class="form-group ">
                <label>MLTCD:</label>
                <input type="text" name="name" value="<?php echo e($raw_data->mltcd); ?>" placeholder="MLTCD" class="form-control" autocomplete="off" />
            </div>
        </div>
        <div class="col-xs-3 col-sm-3 col-md-3">
            <div class="form-group ">
                <label>SB Date:</label>
                <input type="date" name="name" value="<?php echo e($raw_data->sb_date); ?>" placeholder="SB Date" class="form-control" autocomplete="off" />
            </div>
        </div>
        <div class="col-xs-3 col-sm-3 col-md-3">
            <div class="form-group ">
                <label>NTN:</label>
                <input type="text" name="name" value="<?php echo e($raw_data->ntn); ?>" placeholder="NTN" class="form-control" autocomplete="off" />
            </div>
        </div>
       
    </div>
    <div class="row bottom-button-bar">
        <div class="col-12">
            <a type="button" class="btn btn-danger modal-sidebar-close position-relative top-1 closebutton">Close</a>
            <button type="submit" class="btn btn-primary submitbutton">Save</button>
        </div>
    </div>
</form><?php /**PATH C:\xampp82\htdocs\jazacrm\resources\views/management/master/rawData/edit.blade.php ENDPATH**/ ?>