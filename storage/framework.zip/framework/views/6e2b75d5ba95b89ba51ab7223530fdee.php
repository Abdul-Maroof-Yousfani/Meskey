
<div class="alert alert-success hiden">

</div>


<div class="alert alert-danger hiden  print-error-msg">
    <ul class="m-0"></ul>
</div>
<?php /**PATH C:\xampp82\htdocs\jazacrm\resources\views/management/theme/includes/error_success.blade.php ENDPATH**/ ?>